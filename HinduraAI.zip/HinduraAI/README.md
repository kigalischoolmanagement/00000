# Hindura AI

Floating AI assistant for Android 8.0+ (API 26). Open the app, pick a language, a mode and Day/Night, tap **Start**, then tap the small logo on any screen.

## Modes (chosen when the app opens, changeable any time from the top-left option button)
- **Translate** – starts translating the page the moment you tap the logo.
- **Translate + Read** – translates fast, then a **Read** button appears to listen to it.
- **Read only** – reads the live page aloud (black waves, no translation).

## Also
- Chat about the live page under the read area: type or use the mic (your phone's own speech-to-text). The whole conversation stays scrollable.
- "Please wait, we are preparing your voice…" is shown while the voice loads.
- Phone voice is used when it supports the language (instant); otherwise Gemini voice streams in chunks so sound starts quickly.
- Day / Night theme, white popup with a 3D border, tiny background-less icons.

Powered by Google Gemini (default model: `gemini-2.5-flash`, free tier).

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and upload everything from this folder (keep the `.github` folder).
2. Open the **Actions** tab → wait for "Build Android APK" to finish (~5 min).
3. Download `HinduraAI.apk` from **Releases** on your phone and install it.
4. Open Hindura AI → choose language, mode, theme → Start → allow *Display over other apps*, microphone and screen capture.

## API key
The Gemini key is in `app/src/main/java/com/hindura/ai/Config.kt`. Keep the GitHub repo **Private**.
