package com.hindura.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private var night = false

    private val bound = mutableListOf<Pair<TextView, String>>()
    private val langChips = mutableListOf<TextView>()

    private class ModeCard(val key: String, val box: LinearLayout, val title: TextView, val desc: TextView)
    private val modeCards = mutableListOf<ModeCard>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lang() = prefs.getString("lang", "Kinyarwanda") ?: "Kinyarwanda"
    private fun mode() = prefs.getString("mode", "T") ?: "T"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        night = prefs.getBoolean("night", false)
        render()
    }

    // ---------- helpers ----------
    private fun bind(tv: TextView, key: String): TextView { bound.add(tv to key); return tv }

    private fun applyStrings() { bound.forEach { (tv, k) -> tv.text = Lang.s(lang(), k) } }

    private fun label(key: String, p: Pal) = bind(TextView(this).apply {
        textSize = 12f; setTextColor(p.sub); typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.06f; setPadding(dp(4), dp(18), 0, dp(6))
    }, key)

    private fun styleChip(v: TextView, sel: Boolean, p: Pal) {
        v.setTextColor(if (sel) p.userText else p.text)
        v.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        v.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            if (sel) setColor(p.userBg) else { setColor(Color.TRANSPARENT); setStroke(dp(1), p.line) }
        }
    }

    private fun chip(text: String, sel: Boolean, p: Pal) = TextView(this).apply {
        this.text = text; textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(10), dp(11), dp(10), dp(11))
        styleChip(this, sel, p)
    }

    private fun cell() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
        setMargins(dp(3), dp(3), dp(3), dp(3))
    }

    private fun refreshLang(p: Pal) {
        langChips.forEachIndexed { i, c -> styleChip(c, Lang.all[i].first == lang(), p) }
    }

    private fun refreshModes(p: Pal) {
        modeCards.forEach { m ->
            val sel = m.key == mode()
            m.box.background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                if (sel) setColor(p.userBg) else { setColor(Color.TRANSPARENT); setStroke(dp(1), p.line) }
            }
            m.title.setTextColor(if (sel) p.userText else p.text)
            m.desc.setTextColor(if (sel) p.userText else p.sub)
        }
    }

    // ---------- setup screen (shown every time the app is opened) ----------
    private fun render() {
        val p = Pal(night)
        bound.clear(); langChips.clear(); modeCards.clear()
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            if (night) window.decorView.systemUiVisibility and light.inv()
            else window.decorView.systemUiVisibility or light

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        top.addView(TextView(this).apply {
            text = "Hindura AI"; textSize = 21f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(p.text); setPadding(dp(10), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = BevelDrawable(resources.displayMetrics.density, night)
            setPadding(dp(20), dp(16), dp(23), dp(21))
        }
        card.addView(bind(TextView(this).apply {
            textSize = 14f; setTextColor(p.sub); setPadding(dp(4), dp(4), dp(4), 0)
        }, "tagline"), full())

        // language
        card.addView(label("language", p), full())
        Lang.all.map { it.first }.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { n ->
                val c = chip(n, n == lang(), p)
                c.setOnClickListener {
                    prefs.edit().putString("lang", n).apply()
                    refreshLang(p); applyStrings()
                }
                langChips.add(c)
                row.addView(c, cell())
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            card.addView(row, full())
        }

        // mode
        card.addView(label("mode", p), full())
        listOf("T" to ("mT" to "mTd"), "B" to ("mB" to "mBd"), "R" to ("mR" to "mRd")).forEach { (key, k) ->
            val title = bind(TextView(this).apply { textSize = 15f; typeface = Typeface.DEFAULT_BOLD }, k.first)
            val desc = bind(TextView(this).apply { textSize = 12.5f; setPadding(0, dp(2), 0, 0) }, k.second)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
                addView(title); addView(desc)
                setOnClickListener { prefs.edit().putString("mode", key).apply(); refreshModes(p) }
            }
            modeCards.add(ModeCard(key, box, title, desc))
            card.addView(box, full().apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }

        // theme
        card.addView(label("theme", p), full())
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(false to "day", true to "night").forEach { (isNight, k) ->
            val c = bind(chip("", night == isNight, p), k)
            c.setOnClickListener {
                night = isNight
                prefs.edit().putBoolean("night", night).apply()
                render()
            }
            themeRow.addView(c, cell())
        }
        card.addView(themeRow, full())

        // start
        card.addView(bind(TextView(this).apply {
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(p.userText)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply { setColor(p.userBg); cornerRadius = dp(18).toFloat() }
            setOnClickListener { start() }
        }, "start"), full().apply { topMargin = dp(24) })

        refreshModes(p)
        applyStrings()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(28))
        }
        col.addView(top, full().apply { leftMargin = dp(6); bottomMargin = dp(14) })
        col.addView(card, full())
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(col) })
    }

    // ---------- permissions + start ----------
    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Enable “Display over other apps” for Hindura AI, then come back and tap Start")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        proceed()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        proceed()
    }

    private fun proceed() {
        if (OverlayService.running) {
            // already running: just apply the new language / mode / theme
            startService(Intent(this, OverlayService::class.java).putExtra("reload", true))
            moveTaskToBack(true)
        } else askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 100 && res == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (rc == 100) {
            toast("Screen capture permission is needed to read your screen")
        }
    }
}
