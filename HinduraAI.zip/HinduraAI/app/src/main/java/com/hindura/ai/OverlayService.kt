package com.hindura.ai

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.DisplayMetrics
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.CancellationException
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {
    companion object { @Volatile var running = false }

    private enum class V { IDLE, PREP, SAY, LISTEN }
    private class Msg(val user: Boolean, var text: String, val page: Boolean = false) { var tv: TextView? = null }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // screen capture
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null

    // views
    private var bubble: ImageView? = null
    private var panel: PanelLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelShown = false
    private var panelW = 0
    private var drawerOpen = false
    private lateinit var drawer: LinearLayout
    private lateinit var strip: FrameLayout
    private lateinit var wave: WaveView
    private lateinit var status: TextView
    private lateinit var readBtn: LinearLayout
    private lateinit var chatHolder: FrameLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var chatBox: LinearLayout
    private lateinit var input: EditText
    private lateinit var micIc: IconView
    private var emptyView: TextView? = null

    // settings (saved in prefs "cfg")
    private var lang = "Kinyarwanda"
    private var mode = "T"          // T = translate, B = translate + read, R = read only
    private var night = false

    // conversation
    private val msgs = mutableListOf<Msg>()
    private var pageText = ""
    private var pageLang: String? = null
    private var voice = V.IDLE

    // cached screenshot of the page
    private var shotB64: String? = null
    private var shotValid = false
    private var shotPending = false
    private var shotGen = 0
    private val shotWaiters = mutableListOf<(String?) -> Unit>()

    // voice out
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    @Volatile private var speakGen = 0

    // voice in (phone speech-to-text)
    private var sr: SpeechRecognizer? = null
    private var listening = false

    override fun onBind(i: Intent?): IBinder? = null

    private fun s(k: String) = Lang.s(lang, k)
    private fun pal() = Pal(night)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadPrefs() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        lang = p.getString("lang", "Kinyarwanda") ?: "Kinyarwanda"
        mode = p.getString("mode", "T") ?: "T"
        night = p.getBoolean("night", false)
    }

    private fun savePrefs() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("lang", lang).putString("mode", mode).putBoolean("night", night).apply()
    }

    // ---------- lifecycle ----------
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) {
            if (intent?.getBooleanExtra("reload", false) == true) {
                loadPrefs()
                main.post { rebuildPanel() }
            }
            return START_NOT_STICKY
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadPrefs()
        val ch = "hindura"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Hindura AI", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hindura AI")
            .setContentText("●")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 29) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = p
            val (w, h) = realSize()
            val r = newReader(w, h)
            reader = r
            vd = p.createVirtualDisplay("hindura", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            buildUi()
            initTts()
            running = true
            io.execute { Gemini.warmUp() }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        try {
            val (w, h) = realSize()
            held?.close(); held = null
            val old = reader
            val nr = newReader(w, h)
            reader = nr
            vd?.resize(w, h, resources.displayMetrics.densityDpi)
            vd?.surface = nr.surface
            old?.close()
            rebuildPanel()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        running = false
        speakGen++
        try { sr?.destroy() } catch (_: Exception) {}
        try { if (panelShown) wm.removeView(panel) } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        held?.close(); vd?.release(); reader?.close()
        try { projection?.stop() } catch (_: Exception) {}
        tts?.shutdown(); track?.release(); io.shutdownNow()
        super.onDestroy()
    }

    // ---------- screen capture ----------
    private fun realSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) { held?.close(); held = img }
        }, main)
        return r
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val px = p.pixelStride
        val pad = p.rowStride - px * img.width
        val full = Bitmap.createBitmap(img.width + pad / px, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        var bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        val sc = 1400f / maxOf(bmp.width, bmp.height)
        if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
        return bmp
    }

    private fun compress(bmp: Bitmap): String {
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 66, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    /** Called the instant the panel opens (before it is drawn), so the page is captured with zero delay. */
    private fun snapshot() {
        val g = ++shotGen
        shotValid = false
        shotB64 = null
        val img = held ?: return
        val bmp = try { toBitmap(img) } catch (_: Exception) { return }
        shotPending = true
        io.execute {
            val b = try { compress(bmp) } catch (_: Exception) { null }
            main.post {
                if (g == shotGen) { shotB64 = b; shotValid = b != null }
                shotPending = false
                val w = shotWaiters.toList(); shotWaiters.clear()
                w.forEach { it(b) }
            }
        }
    }

    /** Fresh capture with the bubble and panel hidden (used when the page changed). */
    private fun capture(done: (String?) -> Unit) {
        val b = bubble
        val pn = panel
        b?.visibility = View.INVISIBLE
        pn?.visibility = View.INVISIBLE
        main.postDelayed({
            var bm: Bitmap? = null
            try { held?.let { bm = toBitmap(it) } } catch (_: Exception) {}
            b?.visibility = View.VISIBLE
            pn?.visibility = View.VISIBLE
            val g = ++shotGen
            val bmp = bm
            if (bmp == null) { shotValid = false; shotB64 = null; done(null); return@postDelayed }
            io.execute {
                val r = try { compress(bmp) } catch (_: Exception) { null }
                main.post {
                    if (g == shotGen) { shotB64 = r; shotValid = r != null }
                    done(r)
                }
            }
        }, 220)
    }

    private fun ensureShot(cb: (String?) -> Unit) {
        val cached = shotB64
        when {
            shotValid && cached != null -> cb(cached)
            shotPending -> shotWaiters.add(cb)
            else -> capture(cb)
        }
    }

    // ---------- AI ----------
    private fun friendly(e: Exception): String = when {
        e is UnknownHostException -> "No internet connection."
        e is ApiError && (e.code == 400 || e.code == 403) && (e.message ?: "").contains("key", true) ->
            "API key is not valid."
        e is ApiError && e.code == 429 -> "Free limit reached for now. Try again in a minute."
        else -> e.message ?: "Something went wrong."
    }

    private fun fail(m: Msg, text: String) = setMsg(m, "⚠ $text")

    /** Streams an answer into a chat bubble. */
    private fun stream(prompt: String, img: String?, m: Msg, after: ((String) -> Unit)? = null) {
        io.execute {
            try {
                val t = Gemini.generateStream(Config.API_KEY, Config.MODEL, prompt, img, null) { part ->
                    main.post { setMsg(m, part) }
                }
                main.post { setMsg(m, t); after?.invoke(t) }
            } catch (e: Exception) {
                main.post { fail(m, friendly(e)) }
            }
        }
    }

    private fun autoRun() { if (mode == "R") readPage() else translatePage() }

    private fun translatePage() {
        stopSpeaking()
        pageText = ""
        updateStrip()
        val m = addMsg(false, s("working"), page = true)
        ensureShot { b ->
            if (b == null) fail(m, s("cant"))
            else stream("Translate ALL text visible in this screenshot (ignore the status bar) into natural, correct $lang. " +
                    "Keep the order and structure. If it is already $lang, rewrite it simply. Output only the translation.",
                b, m) { t -> pageText = t; pageLang = Lang.code(lang); updateStrip() }
        }
    }

    private fun history(): String {
        val h = msgs.filter { !it.page && it.text.isNotBlank() && it.text != "…" && !it.text.startsWith("⚠") }.takeLast(8)
        if (h.isEmpty()) return ""
        return "Conversation so far:\n" + h.joinToString("\n") { (if (it.user) "User: " else "Assistant: ") + it.text.take(500) } + "\n\n"
    }

    private fun sendQuestion(q: String, byVoice: Boolean) {
        stopSpeaking()
        input.setText("")
        hideKeyboard()
        val hist = history()
        addMsg(true, q)
        val am = addMsg(false, "…")
        ensureShot { b ->
            if (b == null) fail(am, s("cant"))
            else stream("You are Hindura AI. The image is the user's live phone screen (ignore the status bar). " +
                    "Answer the user's question about it. Reply in the same language as the question. Be clear and concise.\n\n" +
                    hist + "Question: $q", b, am) { t ->
                if (byVoice && mode != "T") startSpeak(t, Lang.code(lang))
            }
        }
    }

    private fun sendTyped() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        sendQuestion(q, false)
    }

    private fun sign() {
        stopSpeaking()
        if (drawerOpen) toggleDrawer()
        val m = addMsg(false, "…")
        val p = "Turn this into sign-language guidance for a Deaf reader. Write in English:\n" +
                "GLOSS: the message in sign-language word order, in CAPITAL words (short, no articles).\n" +
                "Then a numbered list: SIGN — handshape, location and movement in one short line.\n" +
                "Simplify long text to the 3–6 key sentences. If no Rwandan Sign Language sign is known, use international sign/ASL and say so.\n"
        if (pageText.isNotBlank()) stream(p + "Content:\n" + pageText.take(1500), null, m)
        else ensureShot { b ->
            if (b == null) fail(m, s("cant")) else stream(p + "Content: the main text visible in the screenshot.", b, m)
        }
    }

    // ---------- read mode: extract the live page text and read it aloud ----------
    private fun splitHeader(raw: String): Pair<String?, String> {
        val t = raw.trimStart()
        if (!t.startsWith("LANG=")) return Pair(null, t)
        val nl = t.indexOf('\n')
        if (nl < 0) return Pair(null, "")
        val code = t.substring(5, nl).trim().lowercase().take(5)
        return Pair(if (code.isEmpty()) null else code, t.substring(nl + 1).trim())
    }

    /** Index just after the first sentence end found between min and max chars, or -1. */
    private fun firstBreak(t: String, min: Int, max: Int): Int {
        val lim = minOf(t.length, max)
        for (i in min until lim) {
            val ch = t[i - 1]
            if ((ch == '.' || ch == '!' || ch == '?' || ch == '\n' || ch == '。') &&
                (t[i].isWhitespace() || ch == '\n' || ch == '。')) return i
        }
        if (t.length >= max) {
            val sp = t.lastIndexOf(' ', max - 1)
            if (sp > min) return sp
        }
        return -1
    }

    private fun readPage() {
        stopSpeaking()
        val gen = speakGen
        pageText = ""
        voice = V.PREP
        updateStrip()
        ensureShot { b ->
            if (gen != speakGen) return@ensureShot
            if (b == null) { voice = V.IDLE; updateStrip(); addMsg(false, "⚠ " + s("cant")); return@ensureShot }
            val prompt = "Extract ALL the readable text visible in this screenshot, in natural reading order. " +
                    "Ignore the status bar, navigation bar and decorative UI. Do NOT translate and add no commentary. " +
                    "Output format: first line exactly LANG=xx where xx is the ISO 639-1 code of the main language of the text, " +
                    "then a blank line, then the text."
            var early: CompletableFuture<String>? = null
            var earlyLen = 0
            io.execute {
                try {
                    val raw = Gemini.generateStream(Config.API_KEY, Config.MODEL, prompt, b, null) { part ->
                        if (early == null && gen == speakGen) {
                            val (code, body) = splitHeader(part)
                            if (code != null && body.length >= 110 && !deviceTtsOk(code)) {
                                val cut = firstBreak(body, 60, 220)
                                if (cut > 0) {
                                    // start speaking the first sentences while the rest is still being extracted
                                    val fut = CompletableFuture<String>()
                                    early = fut
                                    earlyLen = cut
                                    val first = body.substring(0, cut).trim()
                                    main.post { if (gen == speakGen) beginGeminiSpeech(gen, first, fut, code) { if (pageText.isNotBlank()) pageText else first } }
                                }
                            }
                        }
                    }
                    val (code, body) = splitHeader(raw)
                    main.post {
                        if (gen != speakGen) { early?.complete(""); return@post }
                        if (body.isBlank()) {
                            early?.complete("")
                            voice = V.IDLE; updateStrip()
                            addMsg(false, s("nothing"))
                            return@post
                        }
                        pageText = body; pageLang = code
                        val e = early
                        if (e != null) e.complete(body.substring(minOf(earlyLen, body.length)).trim().take(1300))
                        else startSpeak(body, code)
                    }
                } catch (ex: Exception) {
                    early?.completeExceptionally(ex)
                    main.post {
                        if (gen == speakGen) {
                            if (voice == V.PREP) { voice = V.IDLE; updateStrip() }
                            addMsg(false, "⚠ " + friendly(ex))
                        }
                    }
                }
            }
        }
    }

    // ---------- voice question (phone speech-to-text) ----------
    private fun mic() {
        if (listening) { try { sr?.stopListening() } catch (_: Exception) {}; return }
        stopSpeaking()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addMsg(false, "⚠ " + s("micperm")); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMsg(false, "⚠ " + s("nosr")); return
        }
        startListening(true)
    }

    private fun listenEnded() {
        listening = false
        if (voice == V.LISTEN) { voice = V.IDLE; updateStrip() }
    }

    private fun startListening(withLang: Boolean) {
        val r = sr ?: SpeechRecognizer.createSpeechRecognizer(this).also { sr = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { wave.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) { input.setText(t); input.setSelection(t.length) }
            }
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                listenEnded()
                if (!t.isNullOrBlank()) sendQuestion(t.trim(), true) else input.setText("")
            }
            override fun onError(err: Int) {
                // 12 / 13 = language not supported / unavailable: retry with the phone's default language
                if (withLang && (err == 12 || err == 13)) { main.post { startListening(false) }; return }
                if (err == 8) { try { sr?.destroy() } catch (_: Exception) {}; sr = null }   // recognizer busy
                listenEnded()
                input.setText("")
                if (err == 7 || err == 6) addMsg(false, s("nohear"))
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            if (withLang) putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.tag(lang))
        }
        listening = true
        voice = V.LISTEN
        updateStrip()
        try { r.startListening(i) } catch (e: Exception) { listenEnded(); addMsg(false, "⚠ " + s("nosr")) }
    }

    // ---------- voice out ----------
    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        main.post { if (id == "h$speakGen") { voice = V.SAY; wave.level = 0.55f; updateStrip() } }
                    }
                    override fun onDone(id: String?) { main.post { if (id == "h$speakGen") endSpeak() } }
                    override fun onError(id: String?) { main.post { if (id == "h$speakGen") endSpeak() } }
                })
            }
        }
    }

    private fun deviceTtsOk(code: String): Boolean {
        val e = tts ?: return false
        if (!ttsReady) return false
        return try { e.isLanguageAvailable(Locale.forLanguageTag(code)) >= TextToSpeech.LANG_AVAILABLE } catch (_: Exception) { false }
    }

    /** Reads text aloud. Phone voice when it supports the language (instant), otherwise Gemini voice in pipelined chunks. */
    private fun startSpeak(text: String, code: String?) {
        val t = text.take(1500)
        if (t.isBlank()) return
        try { tts?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        val gen = ++speakGen
        voice = V.PREP
        updateStrip()
        val eng = tts
        if (code != null && eng != null && deviceTtsOk(code)) {
            eng.setLanguage(Locale.forLanguageTag(code))
            eng.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h$gen")
            return
        }
        val cut = firstBreak(t, 60, 220)
        if (cut > 0 && t.length > cut + 20)
            beginGeminiSpeech(gen, t.substring(0, cut).trim(), CompletableFuture.completedFuture(t.substring(cut).trim().take(1300)), code) { t }
        else beginGeminiSpeech(gen, t, null, code) { t }
    }

    private fun speakMsg(m: Msg) {
        if (voice == V.PREP || voice == V.SAY) { stopSpeaking(); return }
        if (m.text.isBlank() || m.text == "…" || m.text.startsWith("⚠")) return
        startSpeak(m.text, if (m.page) Lang.code(lang) else null)
    }

    private fun rms(b: ByteArray, off: Int, len: Int): Float {
        var sum = 0.0; var i = off; var n = 0
        while (i + 1 < off + len) {
            val v = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += v.toDouble() * v; i += 2; n++
        }
        return if (n == 0) 0f else minOf(1f, (sqrt(sum / n) / 7000.0).toFloat())
    }

    private fun beginGeminiSpeech(gen: Int, first: String, rest: CompletableFuture<String>?, code: String?, fallback: () -> String) {
        val q = LinkedBlockingQueue<ByteArray>()
        val failure = AtomicReference<Exception?>(null)
        // producer: fetches audio (first chunk now, remaining text in parallel with playback)
        io.execute {
            try {
                Gemini.ttsStream(Config.API_KEY, first) { pcm ->
                    if (gen != speakGen) throw CancellationException()
                    q.put(pcm)
                }
                if (rest != null) {
                    while (!rest.isDone && gen == speakGen) Thread.sleep(40)
                    val r = if (gen == speakGen && !rest.isCompletedExceptionally) rest.getNow("") else ""
                    if (r.isNotBlank()) Gemini.ttsStream(Config.API_KEY, r) { pcm ->
                        if (gen != speakGen) throw CancellationException()
                        q.put(pcm)
                    }
                }
            } catch (e: CancellationException) {
            } catch (e: Exception) {
                failure.set(e)
            } finally {
                q.put(ByteArray(0))
            }
        }
        // consumer: plays audio as it arrives
        io.execute { playQueue(gen, q, failure, code, fallback) }
    }

    private fun playQueue(gen: Int, q: LinkedBlockingQueue<ByteArray>, failure: AtomicReference<Exception?>,
                          code: String?, fallback: () -> String) {
        val rate = 24000
        val minb = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minb, rate))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        val prev = track
        track = at
        try { prev?.release() } catch (_: Exception) {}
        at.play()
        var frames = 0L
        var started = false
        try {
            while (true) {
                val pcm = q.poll(200, TimeUnit.MILLISECONDS)
                if (gen != speakGen) return
                if (pcm == null) continue
                if (pcm.isEmpty()) break
                if (!started) {
                    started = true
                    main.post { if (gen == speakGen) { voice = V.SAY; updateStrip() } }
                }
                var off = 0
                while (off < pcm.size) {
                    if (gen != speakGen) return
                    val len = minOf(4800, pcm.size - off)
                    at.write(pcm, off, len)
                    val lv = rms(pcm, off, len)
                    main.post { if (gen == speakGen) wave.level = lv }
                    off += len; frames += len / 2
                }
            }
            if (!started) {
                // Gemini voice failed before any sound: fall back to the phone voice
                val err = failure.get()
                main.post {
                    if (gen == speakGen) {
                        val e2 = tts
                        val txt = fallback()
                        if (ttsReady && e2 != null && txt.isNotBlank()) {
                            e2.setLanguage(Locale.forLanguageTag(code ?: Lang.code(lang)))
                            e2.speak(txt.take(1500), TextToSpeech.QUEUE_FLUSH, null, "h$gen")
                        } else {
                            endSpeak()
                            if (err != null) addMsg(false, "⚠ " + friendly(err))
                        }
                    }
                }
                return
            }
            val deadline = SystemClock.uptimeMillis() + 4000
            while (gen == speakGen && at.playbackHeadPosition < frames && SystemClock.uptimeMillis() < deadline + frames * 1000 / rate)
                Thread.sleep(40)
        } catch (_: Exception) {}
        main.post { if (gen == speakGen) endSpeak() }
    }

    private fun endSpeak() { if (voice == V.PREP || voice == V.SAY) { voice = V.IDLE; updateStrip() } }

    private fun stopSpeaking() {
        speakGen++
        try { tts?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        if (voice == V.PREP || voice == V.SAY) { voice = V.IDLE; updateStrip() }
    }

    // ---------- chat ----------
    private fun addMsg(user: Boolean, text: String, page: Boolean = false): Msg {
        val m = Msg(user, text, page)
        msgs.add(m)
        if (::chatBox.isInitialized) {
            emptyView?.let { chatBox.removeView(it); emptyView = null }
            renderMsg(m)
            scrollEnd(true)
        }
        return m
    }

    private fun setMsg(m: Msg, t: String) {
        m.text = t
        m.tv?.text = t
        scrollEnd(false)
    }

    private fun scrollEnd(force: Boolean) {
        if (!::chatScroll.isInitialized) return
        chatScroll.post {
            val child = chatScroll.getChildAt(0) ?: return@post
            val dist = child.bottom - (chatScroll.height + chatScroll.scrollY)
            if (force || dist < dp(220)) chatScroll.scrollTo(0, child.height)
        }
    }

    private fun renderMsg(m: Msg) {
        val p = pal()
        val r = dp(16).toFloat(); val k = dp(4).toFloat()
        val tv = TextView(this).apply {
            text = m.text; textSize = 14.5f
            setTextColor(if (m.user) p.userText else p.text)
            setLineSpacing(0f, 1.12f)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            maxWidth = (panelW * 0.8f).toInt()
            background = GradientDrawable().apply {
                setColor(if (m.user) p.userBg else p.ai)
                cornerRadii = if (m.user) floatArrayOf(r, r, r, r, k, k, r, r) else floatArrayOf(r, r, r, r, r, r, k, k)
            }
        }
        m.tv = tv
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { gravity = if (m.user) Gravity.END else Gravity.START })
        if (!m.user && mode != "T") {
            row.addView(IconView(this, Ic.SPEAKER, p.sub).apply {
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { speakMsg(m) }
            }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { gravity = Gravity.START })
        }
        chatBox.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(8) })
    }

    // ---------- UI ----------
    private fun hideKeyboard() {
        if (!::input.isInitialized) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun updateStrip() {
        if (!::strip.isInitialized) return
        val visible = when {
            voice != V.IDLE -> true
            mode == "R" -> true
            mode == "B" -> pageText.isNotBlank()
            else -> false
        }
        strip.visibility = if (visible) View.VISIBLE else View.GONE
        wave.visibility = if (voice == V.SAY || voice == V.LISTEN) View.VISIBLE else View.GONE
        status.visibility = if (voice == V.PREP) View.VISIBLE else View.GONE
        readBtn.visibility = if (voice == V.IDLE && visible) View.VISIBLE else View.GONE
        if (voice == V.SAY || voice == V.LISTEN) wave.start() else wave.stop()
        micIc.setIcon(if (voice == V.LISTEN) Ic.STOP else Ic.MIC)
        input.hint = if (voice == V.LISTEN) s("listening") else s("hint")
    }

    private fun stripTap() {
        when (voice) {
            V.PREP, V.SAY -> stopSpeaking()
            V.LISTEN -> try { sr?.stopListening() } catch (_: Exception) {}
            V.IDLE -> if (mode == "R") readPage() else if (pageText.isNotBlank()) startSpeak(pageText, pageLang)
        }
    }

    private fun chatHeight(): Int {
        val sh = realSize().second
        var h = (sh * 0.36f).toInt().coerceIn(dp(150), dp(330))
        if (mode == "R") h = maxOf(dp(130), h - dp(56))
        if (drawerOpen) h = dp(100)
        return h
    }

    private fun toggleDrawer() {
        drawerOpen = !drawerOpen
        drawer.visibility = if (drawerOpen) View.VISIBLE else View.GONE
        chatHolder.layoutParams = (chatHolder.layoutParams as LinearLayout.LayoutParams).apply { height = chatHeight() }
    }

    private fun openPanel() {
        io.execute { Gemini.warmUp() }
        snapshot()
        wm.addView(panel, panelLp)
        panelShown = true
        autoRun()
    }

    private fun closePanel() {
        stopSpeaking()
        try { sr?.cancel() } catch (_: Exception) {}
        listenEnded()
        hideKeyboard()
        try { wm.removeView(panel) } catch (_: Exception) {}
        panelShown = false
    }

    private fun togglePanel() { if (panelShown) closePanel() else openPanel() }

    private fun rebuildPanel() {
        val was = panelShown
        if (was) { try { wm.removeView(panel) } catch (_: Exception) {} }
        buildPanel()
        if (was) wm.addView(panel, panelLp)
    }

    private fun pill(label: String, sel: Boolean, p: Pal, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12.5f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setTextColor(if (sel) p.userText else p.text)
        typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            if (sel) setColor(p.userBg) else { setColor(Color.TRANSPARENT); setStroke(dp(1), p.line) }
        }
        setOnClickListener { onClick() }
    }

    private fun ic(t: Ic, p: Pal, onClick: () -> Unit) = IconView(this, t, p.text).apply {
        setPadding(dp(9), dp(9), dp(9), dp(9))
        setOnClickListener { onClick() }
    }

    private fun gap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { rightMargin = dp(6) }

    private fun buildDrawer(p: Pal): LinearLayout {
        val d = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (drawerOpen) View.VISIBLE else View.GONE
            setPadding(dp(4), 0, dp(4), dp(4))
        }
        fun label(k: String) = TextView(this).apply {
            text = s(k); textSize = 11f; setTextColor(p.sub); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(4))
        }
        fun scrollRow(row: LinearLayout) = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }

        d.addView(label("language"))
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Lang.all.forEach { (name, _) ->
            langRow.addView(pill(name, name == lang, p) {
                lang = name; savePrefs(); drawerOpen = false
                main.post { rebuildPanel(); if (mode != "R") autoRun() }
            }, gap())
        }
        d.addView(scrollRow(langRow))

        d.addView(label("mode"))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("T" to "mT", "B" to "mB", "R" to "mR").forEach { (m, k) ->
            modeRow.addView(pill(s(k), mode == m, p) {
                mode = m; savePrefs(); drawerOpen = false
                main.post { rebuildPanel(); autoRun() }
            }, gap())
        }
        d.addView(scrollRow(modeRow))

        d.addView(label("theme"))
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(false to "day", true to "night").forEach { (isNight, k) ->
            themeRow.addView(pill(s(k), night == isNight, p) {
                night = isNight; savePrefs()
                main.post { rebuildPanel() }
            }, gap())
        }
        themeRow.addView(pill(s("sign"), false, p) { sign() }, gap())
        d.addView(scrollRow(themeRow))
        return d
    }

    private fun buildUi() {
        // floating logo: tiny, no background
        val img = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val bl = WindowManager.LayoutParams(dp(44), dp(44), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(260)
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        img.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bl.x; sy = bl.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { bl.x = sx + dx; bl.y = sy + dy; wm.updateViewLayout(img, bl) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        bubble = img
        wm.addView(img, bl)
        buildPanel()
    }

    private fun buildPanel() {
        val p = pal()
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        panelW = (realSize().first * 0.94f).toInt()

        val root = PanelLayout(this) { closePanel() }.apply {
            orientation = LinearLayout.VERTICAL
            background = BevelDrawable(resources.displayMetrics.density, night)
            setPadding(dp(16), dp(12), dp(19), dp(15))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) { shotGen++; shotValid = false }
                false
            }
        }

        // header: option button at the TOP-LEFT, then title, minimise, power
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ic(Ic.MENU, p) { toggleDrawer() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        header.addView(TextView(this).apply {
            text = "Hindura AI"; setTextColor(p.text); textSize = 14f
            typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.04f; setPadding(dp(4), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(ic(Ic.MINUS, p) { closePanel() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        header.addView(ic(Ic.POWER, p) { stopSelf() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // option drawer (language / mode / theme)
        drawer = buildDrawer(p)
        root.addView(drawer, LinearLayout.LayoutParams(MATCH, WRAP))

        // voice strip: waves (black in Day), "please wait" message, read button
        wave = WaveView(this).apply { color = p.wave; visibility = View.GONE }
        status = TextView(this).apply {
            text = s("wait"); textSize = 13.5f; setTextColor(p.text); gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0); visibility = View.GONE
        }
        readBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE
            addView(IconView(this@OverlayService, Ic.SPEAKER, p.text), LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(TextView(this@OverlayService).apply {
                text = if (mode == "R") s("again") else s("readBtn")
                textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(p.text); setPadding(dp(8), 0, 0, 0)
            })
        }
        strip = FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), p.line); cornerRadius = dp(14).toFloat() }
            addView(wave, FrameLayout.LayoutParams(MATCH, MATCH).apply { setMargins(dp(10), dp(4), dp(10), dp(4)) })
            addView(status, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(readBtn, FrameLayout.LayoutParams(MATCH, MATCH))
            setOnClickListener { stripTap() }
            visibility = View.GONE
        }
        root.addView(strip, LinearLayout.LayoutParams(MATCH, dp(if (mode == "R") 108 else 50)).apply { topMargin = dp(8) })

        // chat (scrollable, keeps the whole conversation)
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(8)) }
        chatScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(chatBox) }
        chatHolder = FrameLayout(this).apply { addView(chatScroll, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(chatHolder, LinearLayout.LayoutParams(MATCH, chatHeight()).apply { topMargin = dp(8) })

        // ask row: type or speak (phone speech-to-text)
        input = EditText(this).apply {
            hint = s("hint"); setHintTextColor(p.sub); setTextColor(p.text); textSize = 14f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), p.line); cornerRadius = dp(20).toFloat() }
            setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        }
        micIc = ic(Ic.MIC, p) { mic() }
        val askRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        askRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        askRow.addView(micIc, LinearLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(4) })
        askRow.addView(ic(Ic.SEND, p) { sendTyped() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        root.addView(askRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        panel = root
        panelLp = WindowManager.LayoutParams(panelW, WRAP, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(16)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }

        // restore the conversation
        if (msgs.isEmpty()) {
            val ev = TextView(this).apply {
                text = s("tapHint"); textSize = 13.5f; setTextColor(p.sub); gravity = Gravity.CENTER
                setPadding(dp(16), dp(24), dp(16), dp(8))
            }
            emptyView = ev
            chatBox.addView(ev)
        } else {
            emptyView = null
            msgs.forEach { renderMsg(it) }
            scrollEnd(true)
        }
        updateStrip()
    }
}
