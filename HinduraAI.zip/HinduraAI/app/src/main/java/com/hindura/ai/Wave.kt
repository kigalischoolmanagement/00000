package com.hindura.ai

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import kotlin.math.sin

class PanelLayout(ctx: Context, private val onBack: () -> Unit) : LinearLayout(ctx) {
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(e)
    }
}

/** Animated voice waves in a single solid colour (black in Day theme, white in Night). */
class WaveView(ctx: Context) : View(ctx) {
    @Volatile var level = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private var active = false
    private var smooth = 0f
    private val n = 34

    var color: Int = Color.BLACK
        set(v) { field = v; paint.color = v }

    fun start() { if (!active) { active = true; invalidate() } }
    fun stop() { active = false; level = 0f }

    override fun onDraw(c: Canvas) {
        smooth += (level - smooth) * 0.3f
        val t = SystemClock.uptimeMillis() / 1000f
        val w = width.toFloat(); val h = height * 0.8f; val top = height * 0.1f
        val gap = w / n; val bw = gap * 0.5f
        for (i in 0 until n) {
            val wave = (sin(t * 6f + i * 0.6f) * 0.5f + 0.5f)
            val amp = 0.08f + 0.06f * wave + 0.86f * smooth * (0.3f + 0.7f * wave)
            val bh = h * amp
            val x = gap * i + gap / 2
            c.drawRoundRect(x - bw / 2, top + (h - bh) / 2, x + bw / 2, top + (h + bh) / 2, bw / 2, bw / 2, paint)
        }
        if (active) postInvalidateOnAnimation()
    }
}
