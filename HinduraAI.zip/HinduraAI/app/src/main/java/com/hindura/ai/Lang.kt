package com.hindura.ai

object Lang {
    val all = listOf(
        "Kinyarwanda" to "rw", "English" to "en", "Français" to "fr", "Kiswahili" to "sw",
        "Kirundi" to "rn", "Español" to "es", "العربية" to "ar", "中文" to "zh",
        "हिन्दी" to "hi", "Português" to "pt", "Deutsch" to "de"
    )

    private val tags = mapOf(
        "rw" to "rw-RW", "en" to "en-US", "fr" to "fr-FR", "sw" to "sw-KE", "rn" to "rn-BI",
        "es" to "es-ES", "ar" to "ar", "zh" to "zh-CN", "hi" to "hi-IN", "pt" to "pt-BR", "de" to "de-DE"
    )

    fun code(name: String) = all.firstOrNull { it.first == name }?.second ?: "en"

    /** BCP-47 tag for the phone's speech recognizer. */
    fun tag(name: String): String = tags[code(name)] ?: code(name)

    private val en = mapOf(
        "tagline" to "Translate or read anything on your screen.",
        "language" to "Language to translate into",
        "mode" to "Mode",
        "mT" to "Translate",
        "mTd" to "Translate the page you are viewing.",
        "mB" to "Translate + Read",
        "mBd" to "Translate fast, then tap Read to listen.",
        "mR" to "Read only",
        "mRd" to "Read the live page aloud. No translation.",
        "theme" to "Appearance",
        "day" to "Day",
        "night" to "Night",
        "start" to "Start assistant",
        "sign" to "Sign language",
        "hint" to "Ask about this page…",
        "tapHint" to "Tap the logo on any page. Ask your questions below, by voice or text.",
        "cant" to "Couldn't capture the screen. Try again.",
        "working" to "Translating…",
        "wait" to "Please wait, we are preparing your voice…",
        "listening" to "Listening…",
        "nohear" to "I didn't hear anything. Tap the mic and try again.",
        "micperm" to "Microphone permission is needed. Open the app and allow it.",
        "nosr" to "Speech recognition is not available on this phone. Please type.",
        "readBtn" to "Read",
        "again" to "Tap to read again",
        "nothing" to "No readable text found on this page."
    )
    private val rw = mapOf(
        "tagline" to "Hindura cyangwa soma ibiri kuri ecran yawe.",
        "language" to "Ururimi ushaka guhindurirwamo",
        "mode" to "Uburyo",
        "mT" to "Hindura",
        "mTd" to "Hindura urupapuro urimo kureba.",
        "mB" to "Hindura + Soma",
        "mBd" to "Hindura vuba, hanyuma ukande Soma wumve.",
        "mR" to "Soma gusa",
        "mRd" to "Soma urupapuro mu ijwi. Nta guhindura.",
        "theme" to "Isura",
        "day" to "Amanywa",
        "night" to "Ijoro",
        "start" to "Tangira",
        "sign" to "Amarenga",
        "hint" to "Baza ikibazo kuri uru rupapuro…",
        "tapHint" to "Kanda ikirango ku rupapuro urwo ari rwo rwose. Baza ibibazo byawe hasi, mu ijwi cyangwa wandika.",
        "cant" to "Ntibishobotse gufata ecran. Ongera ugerageze.",
        "working" to "Turimo guhindura…",
        "wait" to "Tegereza gato, turimo gutegura ijwi ryawe…",
        "listening" to "Ndumva…",
        "nohear" to "Nta cyo numvise. Kanda mikoro wongere ugerageze.",
        "micperm" to "Hakenewe uruhushya rwa mikoro. Fungura porogaramu uruhe.",
        "nosr" to "Telefoni yawe ntishobora kumva ijwi. Andika.",
        "readBtn" to "Soma",
        "again" to "Kanda wongere usome",
        "nothing" to "Nta nyandiko ishobora gusomwa yabonetse kuri uru rupapuro."
    )
    private val fr = mapOf(
        "tagline" to "Traduisez ou lisez tout ce qui est sur votre écran.",
        "language" to "Langue de traduction",
        "mode" to "Mode",
        "mT" to "Traduire",
        "mTd" to "Traduire la page affichée.",
        "mB" to "Traduire + Lire",
        "mBd" to "Traduction rapide, puis touchez Lire pour écouter.",
        "mR" to "Lecture seule",
        "mRd" to "Lire la page à voix haute. Sans traduction.",
        "theme" to "Apparence",
        "day" to "Jour",
        "night" to "Nuit",
        "start" to "Démarrer",
        "sign" to "Langue des signes",
        "hint" to "Posez une question sur cette page…",
        "tapHint" to "Touchez le logo sur n'importe quelle page. Posez vos questions ci-dessous, à la voix ou par écrit.",
        "cant" to "Capture d'écran impossible. Réessayez.",
        "working" to "Traduction…",
        "wait" to "Veuillez patienter, nous préparons votre voix…",
        "listening" to "J'écoute…",
        "nohear" to "Je n'ai rien entendu. Touchez le micro et réessayez.",
        "micperm" to "L'autorisation du micro est nécessaire. Ouvrez l'application et autorisez-la.",
        "nosr" to "La reconnaissance vocale n'est pas disponible. Veuillez écrire.",
        "readBtn" to "Lire",
        "again" to "Touchez pour relire",
        "nothing" to "Aucun texte lisible sur cette page."
    )
    private val sw = mapOf(
        "tagline" to "Tafsiri au soma chochote kwenye skrini yako.",
        "language" to "Lugha ya kutafsiri",
        "mode" to "Hali",
        "mT" to "Tafsiri",
        "mTd" to "Tafsiri ukurasa unaoutazama.",
        "mB" to "Tafsiri + Soma",
        "mBd" to "Tafsiri haraka, kisha gusa Soma ili usikilize.",
        "mR" to "Soma tu",
        "mRd" to "Soma ukurasa kwa sauti. Bila kutafsiri.",
        "theme" to "Mwonekano",
        "day" to "Mchana",
        "night" to "Usiku",
        "start" to "Anza",
        "sign" to "Lugha ya ishara",
        "hint" to "Uliza swali kuhusu ukurasa huu…",
        "tapHint" to "Gusa nembo kwenye ukurasa wowote. Uliza maswali yako hapa chini, kwa sauti au kuandika.",
        "cant" to "Imeshindwa kunasa skrini. Jaribu tena.",
        "working" to "Inatafsiri…",
        "wait" to "Tafadhali subiri, tunaandaa sauti yako…",
        "listening" to "Inasikiliza…",
        "nohear" to "Sikusikia chochote. Gusa maikrofoni ujaribu tena.",
        "micperm" to "Ruhusa ya maikrofoni inahitajika. Fungua programu uiruhusu.",
        "nosr" to "Utambuzi wa sauti haupatikani. Tafadhali andika.",
        "readBtn" to "Soma",
        "again" to "Gusa kusoma tena",
        "nothing" to "Hakuna maandishi yanayosomeka kwenye ukurasa huu."
    )
    private val tables = mapOf("Kinyarwanda" to rw, "Français" to fr, "Kiswahili" to sw)

    fun s(lang: String, k: String): String = tables[lang]?.get(k) ?: en[k] ?: k
}
