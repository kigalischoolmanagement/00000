package com.hindura.ai

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Black / white palette for Day and Night themes. */
class Pal(val night: Boolean) {
    val bg = if (night) 0xFF000000.toInt() else 0xFFE9E9E9.toInt()
    val face = if (night) 0xFF0B0B0B.toInt() else Color.WHITE
    val text = if (night) 0xFFF2F2F2.toInt() else 0xFF0A0A0A.toInt()
    val sub = if (night) 0xFF9A9A9A.toInt() else 0xFF5E5E5E.toInt()
    val line = if (night) 0xFF2E2E2E.toInt() else 0xFFD2D2D2.toInt()
    val ai = if (night) 0xFF1C1C1C.toInt() else 0xFFF0F0F0.toInt()
    val userBg = if (night) 0xFFF2F2F2.toInt() else 0xFF0A0A0A.toInt()
    val userText = if (night) 0xFF0A0A0A.toInt() else Color.WHITE
    val wave = if (night) Color.WHITE else Color.BLACK
}

/** Rounded card with a three-dimensional (metal bevel + extruded) border and a flat face inside. */
class BevelDrawable(private val dp: Float, private val night: Boolean) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val ext = 3f * dp      // extrusion depth (right / bottom)
        val r = 22f * dp
        val t = 4f * dp        // border thickness
        val bw = w - ext
        val bh = h - ext

        // dark slab behind the card = depth
        p.style = Paint.Style.FILL; p.shader = null; p.color = Color.BLACK
        c.drawRoundRect(RectF(ext, ext, w, h), r, r, p)

        // metallic frame, light top-left to black bottom-right
        p.shader = LinearGradient(0f, 0f, bw, bh,
            if (night) intArrayOf(0xFFE0E0E0.toInt(), 0xFF6A6A6A.toInt(), 0xFF1E1E1E.toInt())
            else intArrayOf(0xFFB0B0B0.toInt(), 0xFF3C3C3C.toInt(), 0xFF000000.toInt()),
            null, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, bw, bh), r, r, p)
        p.shader = null

        // thin highlight on the outer edge
        p.style = Paint.Style.STROKE; p.strokeWidth = dp; p.color = 0x55FFFFFF
        c.drawRoundRect(RectF(dp / 2, dp / 2, bw - dp / 2, bh - dp / 2), r, r, p)

        // flat face
        p.style = Paint.Style.FILL; p.color = if (night) 0xFF0B0B0B.toInt() else Color.WHITE
        c.drawRoundRect(RectF(t, t, bw - t, bh - t), r - t, r - t, p)

        // recessed edge on the face
        p.style = Paint.Style.STROKE; p.strokeWidth = dp
        p.color = if (night) 0xFF000000.toInt() else 0x40000000
        c.drawRoundRect(RectF(t + dp / 2, t + dp / 2, bw - t - dp / 2, bh - t - dp / 2), r - t, r - t, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

enum class Ic { MENU, CLOSE, MINUS, MIC, SEND, SPEAKER, STOP, POWER, SUN, MOON }

/** Tiny line icon, no background. Draw size = view size minus padding. */
class IconView(ctx: Context, private var ic: Ic, c0: Int) : View(ctx) {
    var tint: Int = c0
        set(v) { field = v; invalidate() }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun setIcon(i: Ic) { if (i != ic) { ic = i; invalidate() } }

    override fun onDraw(c: Canvas) {
        val availW = width - paddingLeft - paddingRight
        val availH = height - paddingTop - paddingBottom
        val s = minOf(availW, availH).toFloat()
        if (s <= 0f) return
        val l = paddingLeft + (availW - s) / 2f
        val t = paddingTop + (availH - s) / 2f
        stroke.color = tint; fill.color = tint; stroke.strokeWidth = s * 0.1f
        fun x(v: Float) = l + v * s
        fun y(v: Float) = t + v * s

        when (ic) {
            Ic.MENU -> for (yy in floatArrayOf(0.26f, 0.5f, 0.74f)) c.drawLine(x(0.12f), y(yy), x(0.88f), y(yy), stroke)
            Ic.CLOSE -> {
                c.drawLine(x(0.22f), y(0.22f), x(0.78f), y(0.78f), stroke)
                c.drawLine(x(0.78f), y(0.22f), x(0.22f), y(0.78f), stroke)
            }
            Ic.MINUS -> c.drawLine(x(0.2f), y(0.5f), x(0.8f), y(0.5f), stroke)
            Ic.MIC -> {
                c.drawRoundRect(RectF(x(0.36f), y(0.06f), x(0.64f), y(0.56f)), s * 0.14f, s * 0.14f, stroke)
                c.drawArc(RectF(x(0.22f), y(0.3f), x(0.78f), y(0.76f)), 20f, 140f, false, stroke)
                c.drawLine(x(0.5f), y(0.76f), x(0.5f), y(0.93f), stroke)
                c.drawLine(x(0.34f), y(0.93f), x(0.66f), y(0.93f), stroke)
            }
            Ic.SEND -> {
                val pa = Path()
                pa.moveTo(x(0.1f), y(0.12f)); pa.lineTo(x(0.92f), y(0.5f))
                pa.lineTo(x(0.1f), y(0.88f)); pa.lineTo(x(0.3f), y(0.5f)); pa.close()
                c.drawPath(pa, fill)
            }
            Ic.SPEAKER -> {
                val pa = Path()
                pa.moveTo(x(0.1f), y(0.38f)); pa.lineTo(x(0.28f), y(0.38f)); pa.lineTo(x(0.48f), y(0.18f))
                pa.lineTo(x(0.48f), y(0.82f)); pa.lineTo(x(0.28f), y(0.62f)); pa.lineTo(x(0.1f), y(0.62f)); pa.close()
                c.drawPath(pa, fill)
                c.drawArc(RectF(x(0.34f), y(0.34f), x(0.72f), y(0.66f)), -55f, 110f, false, stroke)
                c.drawArc(RectF(x(0.26f), y(0.2f), x(0.92f), y(0.8f)), -55f, 110f, false, stroke)
            }
            Ic.STOP -> c.drawRoundRect(RectF(x(0.24f), y(0.24f), x(0.76f), y(0.76f)), s * 0.08f, s * 0.08f, fill)
            Ic.POWER -> {
                c.drawArc(RectF(x(0.18f), y(0.2f), x(0.82f), y(0.84f)), -60f, 300f, false, stroke)
                c.drawLine(x(0.5f), y(0.08f), x(0.5f), y(0.5f), stroke)
            }
            Ic.SUN -> {
                c.drawCircle(x(0.5f), y(0.5f), s * 0.17f, stroke)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
                    c.drawLine(x(0.5f + 0.30f * ca), y(0.5f + 0.30f * sa), x(0.5f + 0.43f * ca), y(0.5f + 0.43f * sa), stroke)
                }
            }
            Ic.MOON -> {
                val a = Path().apply { addCircle(x(0.5f), y(0.5f), s * 0.36f, Path.Direction.CW) }
                val b = Path().apply { addCircle(x(0.68f), y(0.36f), s * 0.32f, Path.Direction.CW) }
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, fill)
            }
        }
    }
}
