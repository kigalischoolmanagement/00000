package com.hindura.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiError(msg: String, val code: Int) : Exception(msg)

object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    const val TTS_MODEL = "gemini-2.5-flash-preview-tts"

    /** Opens (and keeps alive) a TLS connection so the next real request starts instantly. */
    fun warmUp() {
        try {
            val c = URL("https://generativelanguage.googleapis.com/").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val code = c.responseCode
            (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() }
        } catch (_: Exception) {}
    }

    private fun open(key: String, model: String, body: JSONObject): HttpURLConnection {
        for (attempt in 0..1) {
            val c = URL("$BASE$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept-Encoding", "identity")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code in 200..299) return c
            val txt = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            if ((code == 503 || code == 429) && attempt == 0) { Thread.sleep(1200); continue }
            val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(200) }
            throw ApiError(msg, code)
        }
        throw Exception("Request failed")
    }

    private fun readSse(c: HttpURLConnection, onData: (JSONObject) -> Unit) {
        c.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (line.startsWith("data:")) {
                    val j = line.substring(5).trim()
                    if (j.isNotEmpty()) onData(JSONObject(j))
                }
            }
        }
    }

    private fun partsOf(j: JSONObject): JSONArray? {
        val cands = j.optJSONArray("candidates") ?: return null
        if (cands.length() == 0) return null
        return cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
    }

    /** Streams text; onText gets the full text so far. */
    fun generateStream(key: String, model: String, prompt: String, imgB64: String?, audioB64: String?,
                       onText: (String) -> Unit): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imgB64 != null) parts.put(JSONObject().put("inline_data",
            JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        if (audioB64 != null) parts.put(JSONObject().put("inline_data",
            JSONObject().put("mime_type", "audio/wav").put("data", audioB64)))
        val gen = JSONObject().put("temperature", 0.3)
        if (model.contains("2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gen)
        val sb = StringBuilder()
        readSse(open(key, model, body)) { j ->
            val ps = partsOf(j)
            if (ps != null) {
                for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
                onText(sb.toString().trimStart())
            }
        }
        if (sb.isBlank()) throw Exception("No answer returned (content may have been blocked).")
        return sb.toString().trim()
    }

    /** Streams 16-bit PCM, 24 kHz mono chunks. */
    fun ttsStream(key: String, text: String, onPcm: (ByteArray) -> Unit) {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Kore")))))
        var got = false
        readSse(open(key, TTS_MODEL, body)) { j ->
            val ps = partsOf(j)
            if (ps != null) {
                for (i in 0 until ps.length()) {
                    val d = ps.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!d.isNullOrEmpty()) { got = true; onPcm(Base64.decode(d, Base64.DEFAULT)) }
                }
            }
        }
        if (!got) throw Exception("No audio returned")
    }
}
